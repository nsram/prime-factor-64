# Fog Sweep 64 source history

These four unified Git patches reproduce the playable HTML from each saved
Site version. The first patch creates `dist/index.html` from an empty
directory. Each later patch applies on top of the previous version. The archive
covers the game source. The hosting manifest and Git repository metadata are
outside its scope.

| Version | Patch | Source commit | Change |
| --- | --- | --- | --- |
| 1 | `0001-prototype.patch` | `6518476f7760a6438bcec7aca0a6621d30def8d6` | Sweep the Fog prototype |
| 2 | `0002-round-review.patch` | `ed683e7920015a24566b57c2c125d46536171053` | Round review and scoring |
| 3 | `0003-first-try-score.patch` | `a833c4f76eca61c80853f11c54a5601dda5cf0d7` | Clearer score label |
| 4 | `0004-game-completion.patch` | `7030ad415267b6e2bfbc924387a10b72853ebbe1` | Fog Sweep 64 and game completion |

## Replay the versions

Unzip the archive, then run these commands from the extracted
`fog-sweep-64-git-diffs` directory. Use a fresh replay directory.

```sh
mkdir replay
cd replay
git init
for patch in ../*.patch; do
  git apply --check "$patch" && git apply "$patch" || exit 1
done
```

Open `dist/index.html` in a browser. To see an intermediate version, stop
after its patch. No build, package install or network connection is required.

Each patch was applied in sequence and the resulting HTML was checked
byte for byte against its corresponding Git commit.

Final `dist/index.html` SHA-256

```
1ac551959ec6fd05837a9e49c817f9d69f1bfff31c8c6d7ccd18d4d9fc45d756
```
