# Prime Factor 64 Git diffs

This archive follows the 20 saved versions of the game source at `dist/index.html`. Patch 01 adds the original game to an empty folder. Each later patch compares the preceding version with the version listed below. The patches cover the game source only.

## Version index

| Patch | Original commit | Saved (Eastern time) | Change |
| --- | --- | --- | --- |
| [01](patches/01-first-playable-55-result-game.patch) | `ef48a00069d12fbd737d2ed37714e689165afe43` | 2026-11-05 22:21:58 EST | First playable 55-result game |
| [02](patches/02-shared-last-digits.patch) | `71185bc476b477cec37b19b053941cb6345f52cd` | 2026-11-05 22:42:09 EST | Shared last digits |
| [03](patches/03-pause-and-resume.patch) | `cd42e406c1a4c000766a7e6e57d52558c356619e` | 2026-11-05 22:49:02 EST | Pause and Resume |
| [04](patches/04-match-and-progress-sounds.patch) | `bcb0e3ff5d9e0832321418bdbc6e9d05719ee6a0` | 2026-11-05 23:03:15 EST | Match and progress sounds |
| [05](patches/05-recall-checks-and-early-scoring.patch) | `264322b4db9f5da1d881b04ea85b8c36a02108f0` | 2026-11-05 23:55:20 EST | Recall checks and early scoring |
| [06](patches/06-matched-cards-grouped-above.patch) | `a6ece5c855526da03bffcbe43652f7185c36ca4c` | 2026-11-06 00:23:43 EST | Matched cards grouped above |
| [07](patches/07-four-tile-logo.patch) | `bf36145e0cc76e3caec0eb109d7ad246e0537820` | 2026-11-06 00:38:49 EST | Four-tile logo |
| [08](patches/08-four-eight-or-twelve-pairs.patch) | `fc6fc8d870c629b279794de44e9e689b8be776b4` | 2026-11-06 08:02:32 EST | Four, eight, or twelve pairs |
| [09](patches/09-board-count-beside-the-selector.patch) | `5e88cb60e614f82bc83fa204855e27d5c1109dff` | 2026-11-06 08:08:37 EST | Board count beside the selector |
| [10](patches/10-four-pair-mode-fits-14-boards.patch) | `663b3354fd7033c84615e0f1cef00649599383a8` | 2026-11-06 08:15:25 EST | Four-pair mode fits 14 boards |
| [11](patches/11-counts-move-into-size-options.patch) | `0c602c28c56aefd601a2d3845bd89e9c12bddf31` | 2026-11-06 08:20:52 EST | Counts move into size options |
| [12](patches/12-prime-match-60.patch) | `8c00efb23f5a9a687d9d9d5d54e11d70ab9f49e0` | 2026-11-06 08:30:28 EST | Prime Match 60 |
| [13](patches/13-logo-links-to-home.patch) | `e7e8fd7104a303ea702b5ab9058d4132d8e9e504` | 2026-11-06 08:46:58 EST | Logo links to Home |
| [14](patches/14-off-two-or-four-recall-checks.patch) | `abd56a7605361c5ee6aeea44b6a89ace7c117353` | 2026-11-06 08:58:36 EST | Off, two, or four recall checks |
| [15](patches/15-prime-factor-64.patch) | `651b3cd46c58b17195d34c8166c6990d0a056982` | 2026-11-06 09:33:17 EST | Prime Factor 64 |
| [16](patches/16-independent-session-length.patch) | `7a1a446c1f821d7f62f79d2cca5f18c9ac444eb5` | 2026-11-06 09:46:11 EST | Independent session length |
| [17](patches/17-setup-resets-on-reload.patch) | `1ad77c338deef9f495621027f86ef91cbc500253` | 2026-11-06 10:30:20 EST | Setup resets on reload |
| [18](patches/18-show-the-entered-product.patch) | `fae08c1aad7f5b0a9f472071831d008622bfccc7` | 2026-11-06 10:49:52 EST | Show the entered product |
| [19](patches/19-victory-fanfare.patch) | `45d71e48c245f37ed1abe521c072f1cda8e787a8` | 2026-11-06 11:01:07 EST | Victory fanfare |
| [20](patches/20-two-line-factor-feedback.patch) | `6b972557d132581114c676228e93502f245e107a` | 2026-11-06 11:30:18 EST | Two-line factor feedback |

## Reconstruct a version

Extract the ZIP. From a separate empty working folder, apply the patches in order through the version you want. Set `PATCH_DIR` to the extracted `patches` directory.

```sh
PATCH_DIR='/path/to/prime-factor-64-git-diffs/patches'
for patch in "$PATCH_DIR"/*.patch; do
  git apply --check "$patch" && git apply "$patch" || break
done
```

Open the reconstructed `dist/index.html` in a browser. Each step was replayed and compared byte for byte with its original Git revision.
